import sqlalchemy
from flask import Flask
import sqlalchemy.orm as orm

SqlAlchemyBase = orm.declarative_base()
app = Flask(__name__)

class Info(SqlAlchemyBase):
    __tablename__ = "info"
    id = sqlalchemy.Column(sqlalchemy.Integer, nullable=True, primary_key=True, autoincrement=True, unique=True)
    name = sqlalchemy.Column(sqlalchemy.TEXT, nullable=True, unique=True)
    number = sqlalchemy.Column(sqlalchemy.Integer, nullable=True, unique=True)
    password = sqlalchemy.Column(sqlalchemy.TEXT, nullable=True, unique=True)
    user = orm.relationship('User')