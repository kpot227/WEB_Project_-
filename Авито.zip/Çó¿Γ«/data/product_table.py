import sqlalchemy
from flask import Flask
import sqlalchemy.orm as orm

SqlAlchemyBase = orm.declarative_base()
app = Flask(__name__)

class Product(SqlAlchemyBase):
    __tablename__ = "product"
    id = sqlalchemy.Column(sqlalchemy.Integer, nullable=True, primary_key=True, autoincrement=True)
    chat = sqlalchemy.Column(sqlalchemy.TEXT, nullable=True, unique=True)
    price = sqlalchemy.Column(sqlalchemy.Integer, nullable=True)
    about_product = sqlalchemy.Column(sqlalchemy.TEXT, nullable=True, unique=True)
    delivery_date = sqlalchemy.Column(sqlalchemy.Integer, nullable=True)
    title = sqlalchemy.Column(sqlalchemy.TEXT, nullable=True, unique=True)
    name_id = sqlalchemy.Column(sqlalchemy.Integer, sqlalchemy.ForeignKey('info.id'), nullable=True)
    user = orm.relationship('User')